import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

export default function ProtectedRoute({ children }) {
  const { user } = useContext(AuthContext);

  if (!user) {
    return <Navigate to="/login" />;
  }

  return children;
};

export function AdminRoute({ children }) {
  const { user } = useContext(AuthContext);

  if (!user || user.role !== "ADMIN") {
    return <Navigate to="/" />;
  }

  return children;
}