import Navbar from "../components/common/Navbar";
import AdminDashboard from "../components/admin/AdminDashboard";

export default function AdminPanel() {
  return (
    <>
      <Navbar />
      <AdminDashboard />
    </>
  );
}