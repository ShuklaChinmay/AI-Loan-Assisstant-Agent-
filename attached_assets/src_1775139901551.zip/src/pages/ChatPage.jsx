import { useState } from "react";
import Navbar from "../components/common/Navbar";
import ChatWindow from "../components/chatbot/ChatWindow";
import ChatInput from "../components/chatbot/ChatInput";
import chatService from "../services/chatService";

export default function ChatPage() {
  const [messages, setMessages] = useState([]);

  const handleSend = async (text) => {
    setMessages((prev) => [...prev, { sender: "user", text }]);

    try {
      const res = await chatService.sendMessage(text);

      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: res.data.reply },
      ]);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <>
      <Navbar />

      <div className="p-6 max-w-2xl mx-auto">
        <h1 className="text-xl font-bold mb-4">AI Loan Chat</h1>

        <ChatWindow messages={messages} />
        <ChatInput onSend={handleSend} />
      </div>
    </>
  );
}