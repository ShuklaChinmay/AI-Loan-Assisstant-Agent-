import Navbar from "../components/common/Navbar";
import Container from "../components/common/Container";

export default function Home() {
  return (
    <>
      <Navbar />
      <Container>
        <h1 className="text-3xl font-bold mt-6">
          Welcome to AI Loan Assistant
        </h1>
        <p className="mt-2">
          Get personalized loan guidance using AI.
        </p>
      </Container>
    </>
  );
}