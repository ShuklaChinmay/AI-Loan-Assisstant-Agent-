import { useState } from "react";
import Navbar from "../components/common/Navbar";
import KYCForm from "../components/kyc/KYCForm";
import DocumentUpload from "../components/kyc/DocumentUpload";
import VerificationStatus from "../components/kyc/VerificationStatus";

export default function ApplyLoan() {
  const [step, setStep] = useState(1);
  const [status] = useState("pending");

  return (
    <>
      <Navbar />

      <div className="p-6 max-w-xl mx-auto">
        {step === 1 && <KYCForm onNext={() => setStep(2)} />}
        {step === 2 && <DocumentUpload onUpload={() => setStep(3)} />}
        {step === 3 && <VerificationStatus status={status} />}
      </div>
    </>
  );
}