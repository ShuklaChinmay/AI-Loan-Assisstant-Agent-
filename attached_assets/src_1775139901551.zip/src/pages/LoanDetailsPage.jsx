import { useParams } from "react-router-dom";
import Navbar from "../components/common/Navbar";
import LoanDetails from "../components/loan/LoanDetails";

export default function LoanDetailsPage() {
  const { id } = useParams();

  // dummy data
  const loan = {
    id,
    name: "Personal Loan",
    rate: 10,
    maxAmount: 500000,
  };

  return (
    <>
      <Navbar />
      <LoanDetails loan={loan} />
    </>
  );
}