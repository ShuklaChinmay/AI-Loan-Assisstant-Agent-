import LoginForm from "../components/auth/LoginForm";
import Navbar from "../components/common/Navbar";

export default function Login() {
  return (
    <>
      <Navbar />
      <div className="flex justify-center mt-10">
        <LoginForm />
      </div>
    </>
  );
}