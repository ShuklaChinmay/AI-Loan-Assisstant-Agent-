import SignupForm from "../components/auth/SignupForm";
import Navbar from "../components/common/Navbar";

export default function Signup() {
  return (
    <>
      <Navbar />
      <div className="flex justify-center mt-10">
        <SignupForm />
      </div>
    </>
  );
}