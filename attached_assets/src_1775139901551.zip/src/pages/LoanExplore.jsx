import Navbar from "../components/common/Navbar";
import Container from "../components/common/Container";
import LoanCard from "../components/loan/LoanCard";

export default function LoanExplore() {
  const loans = [
    { id: 1, name: "Personal Loan", rate: 10, maxAmount: 500000 },
    { id: 2, name: "Home Loan", rate: 8, maxAmount: 2000000 },
  ];

  return (
    <>
      <Navbar />
      <Container>
        <h1 className="text-2xl font-bold mt-4">Available Loans</h1>

        <div className="grid grid-cols-2 gap-4 mt-4">
          {loans.map((loan) => (
            <LoanCard key={loan.id} loan={loan} />
          ))}
        </div>
      </Container>
    </>
  );
}