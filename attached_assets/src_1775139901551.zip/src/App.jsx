import { BrowserRouter, Routes, Route } from "react-router-dom";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import LoanExplore from "./pages/LoanExplore";
import LoanDetailsPage from "./pages/LoanDetailsPage";
import ApplyLoan from "./pages/ApplyLoan";
import ChatPage from "./pages/ChatPage";
import AdminPanel from "./pages/AdminPanel";

// Protected Routes
import ProtectedRoute from "./routes/ProtectedRoute";
import { AdminRoute } from "./routes/ProtectedRoute";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/loans" element={<LoanExplore />} />
        <Route path="/loan/:id" element={<LoanDetailsPage />} />
        <Route path="/chat" element={<ChatPage />} />

        {/* Protected Routes */}
        <Route
          path="/apply/:id"
          element={
            <ProtectedRoute>
              <ApplyLoan />
            </ProtectedRoute>
          }
        />

        {/* Admin Routes */}
        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminPanel />
            </AdminRoute>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;