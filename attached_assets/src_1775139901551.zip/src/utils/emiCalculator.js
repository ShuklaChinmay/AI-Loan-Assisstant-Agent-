export function calculateEMI(amount, rate, time) {
  const r = rate / 12 / 100;

  const emi =
    (amount * r * Math.pow(1 + r, time)) /
    (Math.pow(1 + r, time) - 1);

  return emi.toFixed(2);
}