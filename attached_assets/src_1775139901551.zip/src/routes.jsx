import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import LoanExplore from "./pages/LoanExplore";
import LoanDetailsPage from "./pages/LoanDetailsPage";
import ApplyLoan from "./pages/ApplyLoan";
import ChatPage from "./pages/ChatPage";
import AdminPanel from "./pages/AdminPanel";
import ProtectedRoute from "./routes/ProtectedRoute";
import { AdminRoute } from "./routes/ProtectedRoute";

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/loans" element={<LoanExplore />} />
        <Route path="/loan/:id" element={<LoanDetailsPage />} />
        <Route path="/apply/:id" element={<ApplyLoan />} />
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/apply/:id" element={<ProtectedRoute><ApplyLoan /></ProtectedRoute>} />
        <Route path="/admin" element={<AdminRoute><AdminPanel /></AdminRoute>} />
      </Routes>
    </BrowserRouter>
  );
}