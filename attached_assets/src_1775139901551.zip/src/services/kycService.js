import axios from "axios";

const API = "http://localhost:8080/api/kyc";

const kycService = {
  submitKYC: (data) => axios.post(`${API}/submit`, data),

  uploadDocuments: (formData) =>
    axios.post(`${API}/upload`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    }),

  getStatus: () => axios.get(`${API}/status`),
};

export default kycService;