import axios from "axios";

const AI_API = "http://localhost:5000/chat";

const chatService = {
  sendMessage: (message) => {
    return axios.post(AI_API, { message });
  },
};

export default chatService;