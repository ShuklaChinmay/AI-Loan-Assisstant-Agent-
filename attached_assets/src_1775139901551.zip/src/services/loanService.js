import axios from "axios";

const API = "http://localhost:8080/api/loans";

const loanService = {
  getAllLoans: () => axios.get(API),

  getLoanById: (id) => axios.get(`${API}/${id}`),

  applyLoan: (data) => axios.post(`${API}/apply`, data),
};

export default loanService;