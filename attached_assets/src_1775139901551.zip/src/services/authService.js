import axios from "axios";

const API = "http://localhost:8080/api/auth";

const authService = {
  login: async (data) => {
    return axios.post(`${API}/login`, data);
  },

  signup: async (data) => {
    return axios.post(`${API}/signup`, data);
  },
};

export default authService;