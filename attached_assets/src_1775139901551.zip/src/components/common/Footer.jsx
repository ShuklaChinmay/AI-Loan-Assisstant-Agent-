export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white text-center py-3 mt-10">
      <p>© 2026 AI Loan Assistant. All rights reserved.</p>
    </footer>
  );
}