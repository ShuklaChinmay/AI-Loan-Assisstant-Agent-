import { Link } from "react-router-dom";
import useAuth from "../../hooks/useAuth";

export default function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="flex justify-between items-center px-6 py-3 bg-gray-900 text-white">
      <h1 className="text-xl font-bold">AI Loan Assistant</h1>

      <div className="flex gap-4 items-center">
        <Link to="/">Home</Link>
        <Link to="/loans">Loans</Link>
        <Link to="/chat">Chat</Link>

        {user?.role === "ADMIN" && (
          <Link to="/admin">Admin</Link>
        )}

        {user ? (
          <button onClick={logout} className="bg-red-500 px-3 py-1 rounded">
            Logout
          </button>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/signup">Signup</Link>
          </>
        )}
      </div>
    </nav>
  );
}