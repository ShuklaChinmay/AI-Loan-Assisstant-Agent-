import { useState } from "react";

export default function OTPVerification() {
  const [otp, setOtp] = useState("");

  const verifyOTP = () => {
    console.log("OTP:", otp);
  };

  return (
    <div className="p-6 shadow-lg rounded-xl w-80">
      <h2 className="text-xl font-bold mb-4">Verify OTP</h2>

      <input
        className="border p-2 w-full mb-2"
        placeholder="Enter OTP"
        onChange={(e) => setOtp(e.target.value)}
      />

      <button
        onClick={verifyOTP}
        className="bg-blue-500 text-white w-full p-2 rounded"
      >
        Verify
      </button>
    </div>
  );
}