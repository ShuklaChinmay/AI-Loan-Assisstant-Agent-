import { useState } from "react";
import authService from "../../services/authService";
import { useNavigate } from "react-router-dom";

export default function SignupForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleSignup = async () => {
    if (!form.name) {
    alert("Name is required");
    return;
  }

    if (!validateEmail(form.email)) {
    alert("Invalid email");
    return;
  }

    if (!validatePassword(form.password)) {
    alert("Password must be at least 6 characters");
    return;
  }
    try {
      await authService.signup(form);
      alert("Signup successful");
      navigate("/login");
    } catch (err) {
      console.error(err);
      alert("Signup failed");
    }
  };

  return (
    <div className="p-6 shadow-lg rounded-xl w-80">
      <h2 className="text-xl font-bold mb-4">Signup</h2>

      <input
        className="border p-2 w-full mb-2"
        placeholder="Name"
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />

      <input
        className="border p-2 w-full mb-2"
        placeholder="Email"
        onChange={(e) => setForm({ ...form, email: e.target.value })}
      />

      <input
        className="border p-2 w-full mb-2"
        type="password"
        placeholder="Password"
        onChange={(e) => setForm({ ...form, password: e.target.value })}
      />

      <button
        onClick={handleSignup}
        className="bg-green-500 text-white w-full p-2 rounded"
      >
        Signup
      </button>
    </div>
  );
}