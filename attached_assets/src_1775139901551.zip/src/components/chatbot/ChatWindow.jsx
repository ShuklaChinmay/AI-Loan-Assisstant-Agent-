import ChatMessage from "./ChatMessage";

export default function ChatWindow({ messages }) {
  return (
    <div className="h-96 overflow-y-auto border p-3 rounded bg-gray-50">
      {messages.map((msg, index) => (
        <ChatMessage key={index} sender={msg.sender} text={msg.text} />
      ))}
    </div>
  );
}