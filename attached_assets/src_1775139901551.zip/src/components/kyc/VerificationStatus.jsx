export default function VerificationStatus({ status }) {
  const getColor = () => {
    if (status === "approved") return "text-green-600";
    if (status === "rejected") return "text-red-600";
    return "text-yellow-600";
  };

  return (
    <div className="p-4 border rounded mt-4">
      <h2 className="font-bold mb-2">Verification Status</h2>
      <p className={getColor()}>
        {status === "approved" && "KYC Approved ✅"}
        {status === "rejected" && "KYC Rejected ❌"}
        {status === "pending" && "Verification Pending ⏳"}
      </p>
    </div>
  );
}