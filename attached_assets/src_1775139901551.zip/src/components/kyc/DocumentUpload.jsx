import { useState } from "react";

export default function DocumentUpload({ onUpload }) {
  const [files, setFiles] = useState({
    aadhaar: null,
    pan: null,
  });

  const handleUpload = () => {
    console.log(files);
    onUpload();
  };

  return (
    <div className="p-4 border rounded mt-4">
      <h2 className="text-lg font-bold mb-3">Upload Documents</h2>

      <label className="block mb-2">Aadhaar Card</label>
      <input
        type="file"
        onChange={(e) =>
          setFiles({ ...files, aadhaar: e.target.files[0] })
        }
      />

      <label className="block mt-3 mb-2">PAN Card</label>
      <input
        type="file"
        onChange={(e) =>
          setFiles({ ...files, pan: e.target.files[0] })
        }
      />

      <button
        onClick={handleUpload}
        className="bg-green-500 text-white px-4 py-2 mt-3 rounded"
      >
        Upload
      </button>
    </div>
  );
}