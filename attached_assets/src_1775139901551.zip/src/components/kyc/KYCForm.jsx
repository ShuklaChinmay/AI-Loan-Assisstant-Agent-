import { useState } from "react";

export default function KYCForm({ onNext }) {
  const [form, setForm] = useState({
    fullName: "",
    aadhaar: "",
    pan: "",
  });

  const handleSubmit = () => {
    if (!form.fullName) {
    alert("Name required");
    return;
  }

    if (!validateAadhaar(form.aadhaar)) {
    alert("Invalid Aadhaar number");
    return;
  }

    if (!validatePAN(form.pan)) {
    alert("Invalid PAN number");
    return;
  }
    onNext();
  };

  return (
    <div className="p-4 border rounded">
      <h2 className="text-lg font-bold mb-3">KYC Details</h2>

      <input
        className="border p-2 w-full mb-2"
        placeholder="Full Name"
        onChange={(e) => setForm({ ...form, fullName: e.target.value })}
      />

      <input
        className="border p-2 w-full mb-2"
        placeholder="Aadhaar Number"
        onChange={(e) => setForm({ ...form, aadhaar: e.target.value })}
      />

      <input
        className="border p-2 w-full mb-2"
        placeholder="PAN Number"
        onChange={(e) => setForm({ ...form, pan: e.target.value })}
      />

      <button
        onClick={handleSubmit}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        Next
      </button>
    </div>
  );
}