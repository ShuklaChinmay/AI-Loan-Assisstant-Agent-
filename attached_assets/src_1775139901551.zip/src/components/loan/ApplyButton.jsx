import { useNavigate } from "react-router-dom";

export default function ApplyButton({ loanId }) {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(`/apply/${loanId}`)}
      className="bg-blue-600 text-white px-4 py-2 rounded"
    >
      Apply Now
    </button>
  );
}