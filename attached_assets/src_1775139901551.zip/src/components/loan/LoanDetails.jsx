import EMICalculator from "./EMICalculator";
import EligibilitySection from "./EligibilitySection";
import ApplyButton from "./ApplyButton";
import { formatCurrency } from "../../utils/formatters";

export default function LoanDetails({ loan }) {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">{loan.name}</h1>

      <p className="mt-2">Interest Rate: {loan.rate}%</p>
      <p>Max Amount: {formatCurrency(loan.maxAmount)}</p>

      <div className="mt-6">
        <EligibilitySection />
      </div>

      <div className="mt-6">
        <EMICalculator />
      </div>

      <div className="mt-6">
        <ApplyButton loanId={loan.id} />
      </div>
    </div>
  );
}