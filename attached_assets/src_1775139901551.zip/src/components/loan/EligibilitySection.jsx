export default function EligibilitySection() {
  return (
    <div className="border p-4 rounded">
      <h3 className="font-bold mb-2">Eligibility</h3>
      <ul className="list-disc ml-5">
        <li>Minimum age: 21 years</li>
        <li>Stable income required</li>
        <li>Valid ID proof</li>
        <li>Good credit score preferred</li>
      </ul>
    </div>
  );
}