import { useState } from "react";
import { calculateEMI } from "../../utils/emiCalculator";
import { formatCurrency } from "../../utils/formatters";

export default function EMICalculator() {
  const [amount, setAmount] = useState(100000);
  const [rate, setRate] = useState(10);
  const [time, setTime] = useState(12);

  const calculateEMI = () => {
    const r = rate / 12 / 100;
    const emi =
      (amount * r * Math.pow(1 + r, time)) /
      (Math.pow(1 + r, time) - 1);
    return emi.toFixed(2);
  };

  return (
    <div className="border p-4 rounded">
      <h3 className="font-bold mb-2">EMI Calculator</h3>

      <input
        className="border p-2 w-full mb-2"
        type="number"
        placeholder="Loan Amount"
        onChange={(e) => setAmount(e.target.value)}
      />

      <input
        className="border p-2 w-full mb-2"
        type="number"
        placeholder="Interest Rate"
        onChange={(e) => setRate(e.target.value)}
      />

      <input
        className="border p-2 w-full mb-2"
        type="number"
        placeholder="Duration (months)"
        onChange={(e) => setTime(e.target.value)}
      />

      <p className="mt-2 font-bold">EMI: {formatCurrency(calculateEMI(amount, rate, time))}</p>
    </div>
  );
}