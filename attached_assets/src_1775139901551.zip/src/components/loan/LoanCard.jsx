import { useNavigate } from "react-router-dom";
import { formatCurrency } from "../../utils/formatters";

export default function LoanCard({ loan }) {
  const navigate = useNavigate();

  return (
    <div
      className="p-4 shadow-md rounded-xl border cursor-pointer hover:shadow-lg"
      onClick={() => navigate(`/loan/${loan.id}`)}
    >
      <h2 className="text-lg font-bold">{loan.name}</h2>
      <p>Interest Rate: {loan.rate}%</p>
      <p>Max Amount: {formatCurrency(loan.maxAmount)}</p>
    </div>
  );
}