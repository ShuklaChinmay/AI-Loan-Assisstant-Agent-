import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

      <div className="grid grid-cols-2 gap-4">
        <div
          onClick={() => navigate("/admin/loans")}
          className="p-4 border rounded cursor-pointer hover:shadow"
        >
          <h2 className="font-bold">Manage Loans</h2>
          <p>Approve / Reject Applications</p>
        </div>

        <div
          onClick={() => navigate("/admin/users")}
          className="p-4 border rounded cursor-pointer hover:shadow"
        >
          <h2 className="font-bold">Manage Users</h2>
          <p>View Users & Roles</p>
        </div>
      </div>
    </div>
  );
}