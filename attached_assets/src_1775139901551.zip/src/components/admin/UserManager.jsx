import { useState } from "react";

export default function UserManager() {
  const [users] = useState([
    { id: 1, name: "Abhishek", role: "USER" },
    { id: 2, name: "Admin", role: "ADMIN" },
  ]);

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Users</h2>

      {users.map((user) => (
        <div
          key={user.id}
          className="border p-3 mb-2 rounded flex justify-between"
        >
          <p>{user.name}</p>
          <p className="font-bold">{user.role}</p>
        </div>
      ))}
    </div>
  );
}