import { useState } from "react";
import { formatCurrency } from "../../utils/formatters";

export default function LoanManager() {
  // Dummy data for now
  const [applications, setApplications] = useState([
    { id: 1, name: "Abhishek", amount: 200000, status: "pending" },
    { id: 2, name: "Rahul", amount: 500000, status: "pending" },
  ]);

  const updateStatus = (id, newStatus) => {
    setApplications((prev) =>
      prev.map((app) =>
        app.id === id ? { ...app, status: newStatus } : app
      )
    );
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Loan Applications</h2>

      {applications.map((app) => (
        <div
          key={app.id}
          className="border p-4 mb-3 rounded flex justify-between"
        >
          <div>
            <p><b>{app.name}</b></p>
            <p>Amount: {formatCurrency(app.amount)}</p>
            <p>Status: {app.status}</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => updateStatus(app.id, "approved")}
              className="bg-green-500 text-white px-3 py-1 rounded"
            >
              Approve
            </button>

            <button
              onClick={() => updateStatus(app.id, "rejected")}
              className="bg-red-500 text-white px-3 py-1 rounded"
            >
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}