// ---- PAGE NAVIGATION ----
const pages = ['home','loans','apply','kyc','admin'];
function showPage(name) {
  // Toggle chat wrapper vs normal content
  const chatWrapper = document.getElementById('chat-wrapper');
  const allPages = document.querySelectorAll('.page');
  
  if(name === 'chat') {
    chatWrapper.classList.add('active');
    allPages.forEach(p => { p.classList.remove('active'); p.style.display='none'; });
    document.getElementById('main').style.overflow = 'hidden';
    document.getElementById('page-title').textContent = 'AI Chat Assistant';
  } else {
    chatWrapper.classList.remove('active');
    allPages.forEach(p => { p.classList.remove('active'); p.style.display='none'; });
    const target = document.getElementById('page-'+name);
    if(target) { target.classList.add('active'); target.style.display='block'; }
    document.getElementById('main').style.overflow = '';
    const titles = {home:'Dashboard',loans:'Explore Loans',apply:'Apply for Loan',kyc:'KYC Verification',admin:'Admin Panel'};
    document.getElementById('page-title').textContent = titles[name] || '';
  }
  
  // Update nav
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  const navMap = {home:0, loans:1, apply:2, chat:3, kyc:4, admin:5};
  const navItems = document.querySelectorAll('.nav-item');
  if(navMap[name] !== undefined) navItems[navMap[name]]?.classList.add('active');
}

// Init - show chat by default
showPage('chat');

// ---- EMI CALCULATOR ----
function calcEMI() {
  const P = parseInt(document.getElementById('amt-slider').value);
  const R = parseFloat(document.getElementById('rate-slider').value) / 100 / 12;
  const N = parseInt(document.getElementById('tenure-slider').value);
  const emi = Math.round(P * R * Math.pow(1+R, N) / (Math.pow(1+R, N) - 1));
  const total = emi * N;
  const interest = total - P;
  
  document.getElementById('amt-val').textContent = '₹' + P.toLocaleString('en-IN');
  document.getElementById('rate-val').textContent = parseFloat(document.getElementById('rate-slider').value).toFixed(1) + '%';
  document.getElementById('tenure-val').textContent = N + ' months';
  document.getElementById('emi-monthly').textContent = '₹' + emi.toLocaleString('en-IN');
  document.getElementById('emi-principal').textContent = '₹' + P.toLocaleString('en-IN');
  document.getElementById('emi-interest').textContent = '₹' + interest.toLocaleString('en-IN');
  document.getElementById('emi-total').textContent = '₹' + total.toLocaleString('en-IN');
}

function selectLoan(el) {
  document.querySelectorAll('.loan-type-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
}

function checkEligibility() { /* updates the eligibility section */ }

// ---- CHAT AI ----
let msgCount = 1;
let agentsTriggered = 0;
let isLoading = false;
const conversationHistory = [
  { role: 'user', content: '[SYSTEM] You are LoanAI, an AI-powered loan assistant for an NBFC (Non-Banking Financial Company) in India. You help customers understand personal loans, check eligibility, calculate EMIs, explain the loan process, and guide through KYC. You are friendly, professional, and knowledgeable about Indian banking and finance. Keep responses concise and helpful. When users ask about loans, mention specifics like interest rates (10.5-18% p.a.), tenures (12-84 months), and loan amounts (₹50K to ₹25L for personal loans). Use ₹ (Indian rupee) for amounts. Be encouraging and help them get the best loan deal. Occasionally mention which specialist agent you are engaging (e.g. "Let me connect you with our Sales Agent..." or "Our Underwriting Agent is checking your credit profile...").' },
  { role: 'assistant', content: 'Understood. I am LoanAI, ready to assist customers with their loan journey.' }
];

function updateAgents(stage) {
  const states = {
    idle: { dot: 'idle', status: 'Standby' },
    active: { dot: 'active', status: 'Active' },
    working: { dot: 'working', status: 'Processing...' }
  };
  
  const configs = {
    greeting: { master: 'active', sales: 'idle', verify: 'idle', underwrite: 'idle', sanction: 'idle' },
    sales: { master: 'active', sales: 'working', verify: 'idle', underwrite: 'idle', sanction: 'idle' },
    kyc: { master: 'active', sales: 'active', verify: 'working', underwrite: 'idle', sanction: 'idle' },
    credit: { master: 'active', sales: 'active', verify: 'active', underwrite: 'working', sanction: 'idle' },
    sanction: { master: 'active', sales: 'active', verify: 'active', underwrite: 'active', sanction: 'working' },
  };
  
  const cfg = configs[stage] || configs.greeting;
  const agents = ['master', 'sales', 'verify', 'underwrite', 'sanction'];
  const statuses = {
    master: { active:'Orchestrating conversation', idle:'Standby', working:'Processing...' },
    sales: { active:'Discussing loan terms', idle:'Standby', working:'Negotiating offer...' },
    verify: { active:'Documents reviewed', idle:'Standby', working:'Checking KYC...' },
    underwrite: { active:'Assessment complete', idle:'Standby', working:'Analyzing credit...' },
    sanction: { active:'Letter ready', idle:'Standby', working:'Generating letter...' },
  };
  
  agents.forEach(a => {
    const state = cfg[a];
    document.getElementById('dot-'+a).className = 'agent-dot ' + state;
    document.getElementById('status-'+a).textContent = statuses[a][state];
  });
}

function detectStage(text) {
  const t = text.toLowerCase();
  if(t.includes('sanction') || t.includes('approve') || t.includes('letter')) return 'sanction';
  if(t.includes('credit') || t.includes('cibil') || t.includes('score') || t.includes('eligible')) return 'credit';
  if(t.includes('kyc') || t.includes('document') || t.includes('aadhaar') || t.includes('pan') || t.includes('verify')) return 'kyc';
  if(t.includes('loan') || t.includes('interest') || t.includes('emi') || t.includes('amount') || t.includes('rate') || t.includes('apply')) return 'sales';
  return 'greeting';
}

function getStageLabel(stage) {
  const map = { greeting:'Greeting', sales:'Loan Discussion', kyc:'KYC', credit:'Credit Check', sanction:'Sanctioning' };
  const colors = { greeting:'gray', sales:'amber', kyc:'blue', credit:'blue', sanction:'green' };
  const s = map[stage]||'Greeting'; const c = colors[stage]||'gray';
  return `<span class="tag tag-${c}">${s}</span>`;
}

function getIntentLabel(text) {
  const t = text.toLowerCase();
  if(t.includes('emi') || t.includes('calculat')) return '<span class="tag tag-amber">EMI Query</span>';
  if(t.includes('eligible') || t.includes('qualify')) return '<span class="tag tag-blue">Eligibility</span>';
  if(t.includes('kyc') || t.includes('document')) return '<span class="tag tag-blue">KYC Help</span>';
  if(t.includes('apply') || t.includes('get a loan')) return '<span class="tag tag-green">Loan Application</span>';
  if(t.includes('interest') || t.includes('rate')) return '<span class="tag tag-amber">Rate Inquiry</span>';
  return '<span class="tag tag-gray">General Query</span>';
}

function addMessage(role, content, isHTML=false) {
  const msgs = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = 'chat-msg' + (role === 'user' ? ' user' : '');
  const avatar = `<div class="chat-avatar ${role==='user'?'user':'ai'}">${role==='user'?'AK':'L'}</div>`;
  const bubbleDiv = document.createElement('div');
  bubbleDiv.className = 'chat-bubble ' + (role==='user'?'user':'ai');
  if(isHTML) bubbleDiv.innerHTML = content;
  else bubbleDiv.innerHTML = `<p>${content.replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br/>')}</p>`;
  div.innerHTML = avatar;
  div.appendChild(bubbleDiv);
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  return bubbleDiv;
}

function addTypingIndicator() {
  const msgs = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = 'chat-msg'; div.id = 'typing-indicator';
  div.innerHTML = `<div class="chat-avatar ai">L</div><div class="chat-bubble ai loading"><div class="typing-dots"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function removeTypingIndicator() {
  const t = document.getElementById('typing-indicator');
  if(t) t.remove();
}

async function sendMessage() {
  if(isLoading) return;
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if(!text) return;
  
  input.value = ''; input.style.height = '';
  document.getElementById('quick-btns').style.display = 'none';
  isLoading = true;
  document.getElementById('send-btn').disabled = true;
  
  addMessage('user', text);
  msgCount++;
  document.getElementById('msg-count').textContent = msgCount;
  
  // Detect stage and update UI
  const stage = detectStage(text);
  updateAgents(stage);
  document.getElementById('stage-label').innerHTML = getStageLabel(stage);
  document.getElementById('intent-label').innerHTML = getIntentLabel(text);
  
  const stageAgentCount = { greeting:1, sales:2, kyc:3, credit:4, sanction:5 };
  agentsTriggered = Math.max(agentsTriggered, stageAgentCount[stage]||1);
  document.getElementById('agents-triggered').textContent = agentsTriggered;
  
  addTypingIndicator();
  
  // Build messages for API (skip first two system messages)
  conversationHistory.push({ role: 'user', content: text });
  const apiMessages = conversationHistory.slice(2);
  
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: conversationHistory[0].content,
        messages: apiMessages
      })
    });
    
    const data = await response.json();
    removeTypingIndicator();
    
    let reply = '';
    if(data.content && data.content[0]) reply = data.content[0].text;
    else if(data.error) reply = 'I apologize, I encountered an issue. Please try again.';
    else reply = 'Let me help you with that loan information!';
    
    conversationHistory.push({ role: 'assistant', content: reply });
    
    // Format reply nicely
    const formatted = reply
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/^• /gm, '')
      .replace(/^- /gm, '')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br/>');
    addMessage('assistant', `<p>${formatted}</p>`, true);
    
    // Reset to idle after response
    setTimeout(() => updateAgents('greeting'), 2000);
    
  } catch(err) {
    removeTypingIndicator();
    addMessage('assistant', 'I\'m having trouble connecting right now. Please check your connection and try again. Our AI agents are standing by to assist you!');
  }
  
  isLoading = false;
  document.getElementById('send-btn').disabled = false;
}

function sendQuick(text) {
  document.getElementById('chat-input').value = text;
  sendMessage();
}

function handleKey(e) {
  if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function clearChat() {
  document.getElementById('chat-messages').innerHTML = `
    <div class="chat-msg">
      <div class="chat-avatar ai">L</div>
      <div class="chat-bubble ai">
        <p>👋 Hello! I'm your <strong>LoanAI Assistant</strong>. How can I help you today?</p>
      </div>
    </div>`;
  document.getElementById('quick-btns').style.display = 'flex';
  conversationHistory.splice(2);
  msgCount = 1; agentsTriggered = 0;
  document.getElementById('msg-count').textContent = '1';
  document.getElementById('agents-triggered').textContent = '0';
  document.getElementById('intent-label').innerHTML = '<span class="tag tag-gray">–</span>';
  document.getElementById('stage-label').innerHTML = '<span class="tag tag-gray">Greeting</span>';
  updateAgents('greeting');
}

// ---- KYC ----
function uploadDoc(type) {
  const zone = document.getElementById('pan-upload');
  zone.classList.add('uploaded');
  zone.innerHTML = '<div style="font-size:32px;margin-bottom:12px;">✅</div><div style="font-size:15px;font-weight:500;color:var(--green);margin-bottom:6px;">PAN Card Uploaded!</div><div class="text-sm text-muted">pan_card.jpg • 2.3 MB • Ready for verification</div>';
}

function nextKYCStep() {
  alert('KYC Step 3 completed! Proceeding to Bank Account verification. In the full app, this would advance to the next step.');
}

// ---- ADMIN ----
function approveApp() {
  alert('Application approved! Sanction letter will be generated automatically by the AI agent.');
}

function submitApplication() {
  alert('Application submitted successfully! Our AI agents will process your request within minutes. You will receive an SMS and email confirmation shortly.');
}

// ---- AUTH ----
function toggleAuth() {
  document.getElementById('auth-overlay').style.display = 'flex';
}
function closeAuth() {
  document.getElementById('auth-overlay').style.display = 'none';
}
document.getElementById('auth-overlay').addEventListener('click', function(e) {
  if(e.target === this) closeAuth();
});